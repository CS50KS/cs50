#include <cs50.h>
#include <stdio.h>

int main(void)
{
    
    int array[] = {5, 10, 15, 20, 25};
    int* ptr = array;
    int length = sizeof(array) / sizeof(int);
    
    while (ptr != array + length) { // array - адрес первого элемента массива, length - размер массива
// щоб не виконувати операцію додавання довжини до першого елемента масиву (при кожній ітерації), можна взяти за умову (ptr != outsideelement)
// що цікаво: я не бачив вашого варанту, а просто сам дійшов до того, що так треба зробити :)

        printf("%d \n", *ptr);
        ptr++;
        
    };
    
}