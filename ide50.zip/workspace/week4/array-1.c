#include <cs50.h>
#include <stdio.h>

int main(void){
    
    int array[] = {5, 10, 7, 12, 35};
    
    int* outsideelement = array + sizeof(array)/sizeof(int); // Перший елемент, який знаходиться за межами масиву
// Формула визначення вказівника на останній елемент масиву: нульовий (array) + довжина (sizeof(array)/sizeof(int)) -1
    for (int *ptr = array; ptr != outsideelement; ptr++){ // проходимо весь масив
        printf("* %i\n", *ptr); // друкує черговий елемент масиву, тобто 'зірочка' ('*') означає, що ми працюємо ІЗ ЗНАЧЕННЯМ, на яке посилоється вказівник (ptr)
    }


/* Цей варіант - це так, як робити не варто (хоча він і працює):
    for (int *ptr_n = ptr; *ptr_n != *(ptr + sizeof(array)/sizeof(int)); ptr_n++){
        printf("* %i\n", *ptr_n);
        // "\0" признак конца строки. У нас массив целых чисел
    }
*/    
/* Антон, используйте указатель!!!
    for (int a = 0; a<sizeof(array)/sizeof(int); a++){
        printf("%i\n", *(ptr+a)); // Так?  // Ні- Виконати перебір за допомогою вказівника 
    }
*/    
// Стаття на хабрі (https://habrahabr.ru/post/251091/)
}