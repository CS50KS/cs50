/*
Мое видение задачи Greedy с применением структур. 
Просмотрите внимательно код. Скопируйте себе и поиграйтесь.

Подумайте, что необходимо прописать, чтобы вывести сообщение если все монетки закончились, а сдача не выдана полностью!!!
Vlad Kotelenets
*/
#include <cs50.h>
#include <stdio.h>
#include <math.h>
//#include <>

float GetFloatData(string message); // прототип функции

struct coin {
    int coin; // номинал монеты
    int amt; // количество монет данного номинала
};

int main(void){
    float total;  // Сумма к оплате
    float cash;   // Принято к оплате
    int money;    // Сдача
    int number;   // Количество монет
    
    struct coin wallet[] = { // наш массив данных типа struct coin
        {50, 10}, // 10 монет номиналом 50 центов
        {25, 10}, // 10 монет номиналом 25 центов
        {10, 10}, // 10 монет номиналом 10 центов
        {5, 10},  // 10 монет номиналом 5 центов
        {1, 10}    // 10 монет номиналом 1 цент
    };
    
    total = GetFloatData("Total sum to paying : "); // Выставили счет к оплате
    cash = GetFloatData("Accepted for payment : "); // Оплатили    printf("Money back is : %8.2f \n\n", cash - total); // Наша сдача

    money = roundf((cash - total) * 100);
    printf("Return the money: \n");
    
    for (int i = 0, length = sizeof(wallet) / sizeof(struct coin); i < length; i++) { // перебираем элементы массива данных типа struct coin
        number = 0; // обнуляем счетчик монет
        while (money >= wallet[i].coin && wallet[i].amt > 0 ) { // если сдача больше номинала и количество монет данного номинала больше нуля
            money -= wallet[i].coin; // уменьшили сдачу на номинал (выдали монетку)
            wallet[i].amt--;         // уменьшили количество монет (списали монетку)
            number++;                // увеличили счетчик монет
            };
        if (number > 0) printf("%3d coin - %3d pieces\n", wallet[i].coin, number); // если монеты данного номинала были выданы, то сообщаем об этом
    };
}

float GetFloatData(string message) {
        float data;
        do {
            printf("%s", message);
            data = GetFloat();
            } while (data <= 0);

            return data;
}