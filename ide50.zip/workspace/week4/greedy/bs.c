#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>

void rabbitsort(int ar[], int size);
void change (int *a, int *b);
int* binaryS(int c, int ar[], int size);
int lineCounter (int* c, int lsize, int rsize);

int main(void){

    int arr[] = {9, 4, 0, 4, 3, 4, 1, 6, 3, 2, -5, 4, 6, 7};
    int size = sizeof(arr)/sizeof(int);

    rabbitsort(arr, size);


    int number;
    bool goback;
    printf("  E");
    do {
        printf("nter some integer to search: ");
        number = GetInt();
        goback = false;
        if (number > arr[size-1] || number < arr[0]){
            goback = true;
            printf("Your number (%i) even outside the array! That`s why...\nREe", number);
        }
    } while (goback);
        int*x;
        if (number == arr[size-1]) {
            printf("Hm... Your number coincides with the largest element of array\n");
            x = binaryS(number, &arr[size-1], 1);
        }
        else if (number == arr[0]) {
            printf("From this we started...\n");
            x = binaryS(number, &arr[0], 1);
        }
        else x = binaryS(number, arr, size);

    if (x != NULL) {
        printf("You search \"%i\" and it was found", *x);
        int count = lineCounter(x, x-arr, size-1-(x-arr));
        string countSey = "\0";
        
        int case4 = (count>3) ? 4: count;
        switch (case4){
            case 1: countSey = "only once.\n";
            break;
            case 2: countSey = "twise.\n";
            break;
            case 3: countSey = "three times.\n";
            break;
            case 4: countSey = " many";
    
            default: countSey = " times\n";
        }
        printf(" %s ", countSey);
printf("(left of the cell with this number was %li cell of array,\non the right side it was %li cell, size of array - %i)\n", x-arr, size-1-(x-arr), size);
    } else printf("Not found!\n");
}

int* binaryS(int c, int ar[], int size){
    int* middl = ar;
    if (c == *middl) return middl;
    while(size > 1){
        size /= 2;
        middl = ar+size;
        if (c > *middl) {
printf("* binarysearch in right side (your namber > middle (%i))\n", *middl);
            ar=middl;
            continue;
        }
        if (c == *middl) return middl;
printf("* binarysearch in left side (your namber(%i) < middle (%i))\n", c, *middl);
    }
    
    if (c == *middl) return middl;
    if (c == *(middl+1)) return middl+1;
    if (c == *(middl-1)) return middl-1;
    return NULL;
}

void rabbitsort(int l[], int size){
    for (int* runner = l, *r = l+size-1; l < r; r--, l++){
        while(++runner < r){
            if (*(runner-1) > *runner) change(runner, runner-1);
        }
        while(--runner > l){
            if (*(runner+1) < *runner) change(runner, runner+1);
        }
    }
}

void change (int *a, int *b){
    int temp = *a;
    *a = *b;
    *b = temp;
}

int lineCounter (int* c, int lsize, int rsize){
    int count = 1;
    int* cc = c;
    while (*c == *++cc){
        if(rsize-->0) count++;
    }
    cc--;
    while (*cc == *--c){
        if(lsize-->0) count++;
    }
    return count;
}