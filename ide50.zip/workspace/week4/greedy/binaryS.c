/* це експерименти з вказівниками

*/

#include <cs50.h>
#include <stdio.h>

int* binaryS(int c, int at[], int size);

int main(void){
    // TODO - бо створено з шаблону
    int arr[] = {1, 2, 3, 4, 5, 6, 7, 8};
    
  //  printf("you search ");
    int* x = binaryS(8, arr, sizeof(arr)/sizeof(int)-1);
    printf("%d\n", *x);
}
int* binaryS(int c, int ar[], int size){
    size /= 2;
printf("%i   ", size);
    int* middl = ar+size;
//printf("c = %i, middl* %i\n", c, *middl);
if (size == 0){
        if (c == *middl) {
printf("find in last step\n");
        return middl;} else return NULL;}
    if (c > *middl) binaryS(c, middl+1, size);
    if (c == *middl) {
printf("!\n");
        return middl;}
    binaryS(c, ar, size);
    return NULL;
}