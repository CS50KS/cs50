/* це експерименти з вказівниками

*/

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h> // itoa();

void rabbitsort(int ar[], int size);
int* binaryS(int c, int ar[], int size);
int lineCounter (int* c, int lsize, int rsize);

int main(void){
//  printf("Enter some int-array:");
    int arr[] = {1, 2, 3, 4, 5, 6, 7, 8};
    int size = sizeof(arr)/sizeof(int);

// rabbit


    int number;
    bool goback;
    do {
        goback = false;
        printf("Enter some integer to search: ");
        number = GetInt();
        if (number > arr[size-1] || number < arr[0]){ // якщо не робити цю перевірку (що не розумно), то треба буде перевіряти чи middl+1 та middl-1 не виходять за межі масиву
            if (number ==  arr[size-1]) printf("Hm... It`s last element of arr...\n");
            goback = true;
            printf(" (your number even outside the array!)\n");
        }
    } while (goback);
    
    int* x = binaryS(number, arr, size);
//    printf("%d\n", *binaryS(8, arr, sizeof(arr)/sizeof(int)); // просто вивести число

    if (x != NULL) {
        printf("You search %i and it was found", *x);
        int count = lineCounter(x, x-arr, size-1-(x-arr));
        string countSey = "\0";
        
        int case4 = (count>3) ? 4: count;
        switch (case4){
            case 1: countSey = " only once.";
            break;
            case 2: countSey = " twise";
            break;
            case 3: countSey = " three";
            break;
            case 4: countSey = itoa(count, countSey, 0);
            default: countSey = " times";
        }
        printf(" %s ", countSey);
printf(" (left of this number was %li cell array, on the right side it was %li cell, size of array - %i)\n", x-arr, size-1-(x-arr), size);
    } else printf("not found\n");
}
int* binaryS(int c, int ar[], int size){
    int* middl = ar;
    if (c == *middl) return middl;
    while(size > 1){
        size /= 2;
        middl = ar+size;
        if (c > *middl) {
printf("search in right side (your namber > middle (%i))\n", *middl);
            ar=middl;
            continue;
        }
        if (c == *middl) return middl;
        if (c == *(middl+1))
printf("search in left side (your namber(%i) < middle (%i))\n", c, *middl);
    }
    return (c == *middl) ? middl : NULL;
}
/*
void rabbitsort(int ar[], int size){
    int temp, i = 0;
    while (i < --size){
        if ()
        
        while(size > i){
            if (values[i] > values[size]){
                temp = values[size];
                values[size] = values[i];
                values[i] = temp;
            }
            i++;
        }
        i = 0;
    }
    return;
}
*/
int lineCounter (int* c, int lsize, int rsize){
    int count = 1;
    int* cc = c;
    while (*c == *++cc){
        if(rsize-->0) count++;
    }
    cc--;
    while (*cc == *--c){
        if(lsize-->0) count++;
    }
    return count;
}