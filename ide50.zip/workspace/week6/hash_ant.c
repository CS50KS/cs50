#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

struct eWord{
    char* word;
    struct eWord* pointer;
};

int hash(char* ww);
int main(void)
{
    struct eWord* arrABC[26] = {NULL};
    struct eWord* runner;
    char* neww;
    int index = 0;
    
    printf("Please input some words, what You want (for exit - q/Q)\n");
    while ( true ){
        neww = GetString();
        index = hash(neww);
        if (index == 16 && strlen(neww)==1) {
            printf("\n Becouse of You, on this moment our program learned such words:\n");
            break;
        }
/* Щоб вставляти нове слово у кінець, можна використати:
        if (arrABC[index] != NULL){
            runner = arrABC[index];
            while(runner != NULL)
                runner = runner -> pointer;
            }
*/
        struct eWord* NewElement = malloc(sizeof(struct eWord));
        if (NewElement == NULL){
            printf("malloc sey \"Break!\"");
            break;
        }
        NewElement -> pointer = arrABC[index];
        NewElement -> word = neww;
        arrABC[index] = NewElement;
        
//        printf("%s\n", neww);
    } // пробував while ( strlen(neww)!=1 && tolower(*neww) != 'q') і не розумію, чому && працює як || . У результаті вирішив, що слова мають бути більше ніж 1 літера
    
    for (index = 0; index<26; index++) {
        if (arrABC[index] == NULL) continue; // to avoid void string
        printf("%c \n", index+65);
        runner = arrABC[index];
        for( ; runner != NULL; runner = runner->pointer) {
            printf("%s\n", runner->word);
        }
        printf("\n");
    }
    
}

int hash(char* ww){
    return toupper(*ww)-'A';
}