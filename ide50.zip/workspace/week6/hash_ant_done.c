/*

*/
#include <cs50.h>
#include <stdio.h>
#include <string.h> //strcmp(), strlen()
#include <ctype.h> //isalpha()

struct eWord{
	char* word;
	struct eWord* nega;
	struct eWord* pozi;
};

typedef struct head{
	int trend;
	struct eWord* min;
	struct eWord* middl;// pointer to middle
} head;

//#define CELLS;
int index,
	CELLS;
struct eWord* runner;

void input(head arr[]);
void hash_print(head arr[]);
int main(int argc, char* argv[]){
	if(argc==2 && *argv[1]=='?') {printf("./hash [file.txt]\n"); return 0;} // ./hash <'key' or index> [file.txt]
//	if(argc == 2) argv[1]; return 0;




//	printf("How many paragrath in dictionary? (Maybe 26?): "); // Можна реалізувати введення "ключа" (символів, з яких починаються слова)
	CELLS = 26; //	CELLS = (GetInt();)? ;



	head arrABC[CELLS];
	for(int i = 0; i<CELLS; i++){
		arrABC[i].min = NULL;
		arrABC[i].trend = 0;
	}; // initialize each element of arrABC
	input(arrABC);
	hash_print(arrABC);
}

void input(head arr[]){
	printf("Input some words (for exit, press Enter)\n");
	while(true){
		struct eWord* NewElement = malloc(sizeof(struct eWord));
		if (NewElement == NULL){
			printf("\nmalloc sey \"Break!\", but... ");
			break;
		}
		NewElement->word = GetString();
		if (NewElement->word == NULL){
			printf(" - try shorter word or press Enter (to exit)\n");
			free(NewElement);
			continue;
		}
		if(*NewElement->word == '\0') break; //		if (*NewElement->word == '\0' || ((*NewElement->word == 'q' || *NewElement->word == 'Q') && strlen(NewElement->word)==1)) break;
		if (!isalpha(*NewElement->word)) {printf(" - word don`t added. Try else\n"); continue;} // Alert about non-alphabet
//		if (*NewElement->word < 'a' || *NewElement->word > 'Z' || (*NewElement->word  > 'z' && *NewElement->word < 'A')) continue; // without ALERT

		index = (*NewElement->word<'a') ? *NewElement->word % CELLS : (*NewElement->word - 32)% CELLS; // логічніше, мабуть, наповнювати всім підряд, а виводити вже з перевіркою (за ключем)
		
		if (arr[index].min == NULL){
			NewElement->nega = NULL;
			NewElement->pozi = NULL;
			arr[index].middl = NewElement; 
			arr[index].min = NewElement;
			continue;
			}
		runner = arr[index].middl;
		if(strcmp(NewElement->word, runner->word) < 0){
			arr[index].trend--;
			while(runner->nega != NULL){
				runner = runner->nega;
				if(strcmp(NewElement->word, runner->word) < 0) continue;
				else break;
			}
				if(strcmp(NewElement->word, runner->word) == 0) {printf(" - Alrady exists!\n"); continue;}
			if (runner->nega == NULL){
				arr[index].min = NewElement;
				NewElement->nega = NULL;
				NewElement->pozi = runner;
				runner->nega = NewElement;
				continue;
			}
			NewElement->nega = runner;
			NewElement->pozi = runner->pozi;
			runner->pozi->nega = NewElement;
			runner->pozi = NewElement;
		} else if(strcmp(NewElement->word, runner->word) > 0){
			arr[index].trend++;
			while((strcmp(NewElement->word, runner->word) > 0) && runner->pozi != NULL){
				runner = runner->pozi;
			}
				if(strcmp(NewElement->word, runner->word) == 0) {printf(" - Alrady exists!\n"); continue;}
			if (runner->pozi == NULL){
				NewElement->pozi = NULL;
				NewElement->nega = runner;
				runner->pozi = NewElement;
				continue;
			}
			NewElement->pozi = runner;
			NewElement->nega = runner->nega;
			runner->nega->pozi = NewElement;
			runner->nega = NewElement;
			} else {
			printf(" - Alrady exists!\n"); continue; // strcmp(NewElement->word, arr[index].middl->word) == 0
		}
		if (arr[index].trend == -2){arr[index].middl = arr[index].middl->nega; arr[index].trend++;}
		if (arr[index].trend == 2) {arr[index].middl = arr[index].middl->pozi; arr[index].trend--;}
	}

}
void hash_print(head arr[]){ // key, keySize
	printf("\n Becouse of You, dictionary has:");
//int start = (key[0]==65)? 13 : arr[0];
	for(int i = 13; i < 39; i++){ //i = key[0]; i<key[keySize-1] 		if (arr == NULL) {arr++; continue;} // to avoid void string

		index = i%CELLS;
		if(arr[index].min == NULL){
	//		if (arrABC[index].middl == NULL) continue;
	//		printf("%s\n\n", arrABC[index].middl->word);
			continue;
		}
		printf("\n		%c\n", i+52); //52 = 'A'(65) - ('A'%CELLS(26))(13);
		for(runner = arr[index].min; runner != NULL; runner = runner->pozi) {
//			if(*runner->word != i+52) continue; // if(*runner->word != index+84) continue; - щоб виводити лише букви з "А" & "a"(якщо додавали у словник все підряд)
			printf("%s\n", runner->word);
		}
	}
}