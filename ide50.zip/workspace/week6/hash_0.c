#include <cs50.h>
#include <stdio.h>
#include <ctype.h> // for toupper()
#include <string.h> // for strlen()

struct eWord{
    char* word; // wihout[20] !
    struct eWord* pointer;
};

int hash(char* ww);
int main(void)
{
    struct eWord* arrABC[26] = {NULL};
    printf("Input words (single letter - for exit):\n");
    while (true) {
        char* neww = GetString();
        if (neww == NULL) {
            printf("Very long word. Try more short\n");
            continue;
        }
        if (strlen(neww) == 1) break; // якщо введено лише одну літеру
        
        struct eWord* element = malloc(sizeof(struct eWord));
        if (element == NULL){
            printf("malloc sey \"Break!\"");
            break;
        }
        //
        
    }
}

int hash(char* ww){
    return toupper(*ww)-'A'; // можна використати розіменування, замість ww[0]
}