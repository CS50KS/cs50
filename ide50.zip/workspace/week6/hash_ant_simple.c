#include <cs50.h>
#include <stdio.h>
#include <string.h> //strcmp(), strlen()
#include <ctype.h> //toupper()

struct eWord{
	char* word;
	struct eWord* nega;
	struct eWord* pozi;
};

typedef struct head{
	int trend;
	struct eWord* min;
	struct eWord* middl;// pointer to middle
} head;

int main(int argc, char* argv[]){
	if(argc==2 && *argv[1]=='?') {printf("./hash [file.txt]\n"); return 0;} // ./hash <'key' or index> [file.txt]
//	if(argc == 2) argv[1]; return 0;




//	printf("How many paragrath in dictionary? (Maybe 26?): "); // Можна реалізувати введення "ключа" (символів, з яких починаються слова)
	int index,
		CELLS = 26; //#define
//		CELLS = GetInt();
	struct eWord* runner;
	head arrABC[CELLS];
	for(int i = 0; i<CELLS; i++){
		arrABC[i].min = NULL;
		arrABC[i].middl = NULL;
		arrABC[i].trend = 0;
	}; // initialize each element of arrABC

	printf("Input some words (for exit, press Enter)\n");
	while(true){
		struct eWord* NewElement = malloc(sizeof(struct eWord));
		if (NewElement == NULL){
			printf("\nmalloc sey \"Break!\", but... ");
			break;
		}
		NewElement->word = GetString();
		if (NewElement->word == NULL){
			printf(" - try shorter word or press Enter (to exit)\n");
			free(NewElement);
			continue;
		}
		if(*NewElement->word == '\0') break;
//		if (*NewElement->word == '\0' || ((*NewElement->word == 'q' || *NewElement->word == 'Q') && strlen(NewElement->word)==1)) break;
		if (!isalpha(*NewElement->word)) {printf(" - word don`t added. Try else\n"); continue;} // Alert about non-alphabet
//		if (*NewElement->word < 'a' || *NewElement->word > 'Z' || (*NewElement->word  > 'z' && *NewElement->word < 'A')) continue;

		index = (*NewElement->word<'a') ? *NewElement->word % CELLS : (*NewElement->word - 32)% CELLS;
		
		if (arrABC[index].middl == NULL){
			NewElement->nega = NULL;
			NewElement->pozi = NULL;
			arrABC[index].middl = NewElement; 
			arrABC[index].min = NewElement;
			continue;
			}
				if(strcmp(NewElement->word, arrABC[index].middl->word) == 0) {printf(" - Alrady exists!\n"); continue;}//
		runner = arrABC[index].middl;
		if(strcmp(NewElement->word, runner->word) < 0){
			arrABC[index].trend--;
			while(runner->nega != NULL){
				runner = runner->nega;
				if(strcmp(NewElement->word, runner->word) < 0) continue;
				else break;
			}
				if(strcmp(NewElement->word, runner->word) == 0) {printf(" - Alrady exists!\n"); continue;}
			if (runner->nega == NULL){
				arrABC[index].min = NewElement;
				NewElement->nega = NULL;
				NewElement->pozi = runner;
				runner->nega = NewElement;
				continue;
			}
			NewElement->nega = runner;
			NewElement->pozi = runner->pozi;
			runner->pozi->nega = NewElement;
			runner->pozi = NewElement;
		} else {
			arrABC[index].trend++;
			while((strcmp(NewElement->word, runner->word) > 0) && runner->pozi != NULL){
				runner = runner->pozi;
			}
				if(strcmp(NewElement->word, runner->word) == 0) {printf(" - Alrady exists!\n"); continue;}
			if (runner->pozi == NULL){
				NewElement->pozi = NULL;
				NewElement->nega = runner;
				runner->pozi = NewElement;
				continue;
			}
			NewElement->pozi = runner;
			NewElement->nega = runner->nega;
			runner->nega->pozi = NewElement;
			runner->nega = NewElement;

			}
		if (arrABC[index].trend == -2){arrABC[index].middl = arrABC[index].middl->nega; arrABC[index].trend++;}
		if (arrABC[index].trend == 2) {arrABC[index].middl = arrABC[index].middl->pozi; arrABC[index].trend--;}
	}
	printf("\n Becouse of You, dictionary has:");

	for(int i = 13; i < 39; i++){ //
		index = i%CELLS;
		if(arrABC[index].min == NULL){
	//		if (arrABC[index].middl == NULL) continue;
	//		printf("%s\n\n", arrABC[index].middl->word);
			continue;
		}
		printf("\n		%c\n", i+52); //52 = 'A'(65) - ('A'%CELLS(26))(13);
		for(runner = arrABC[index].min; runner != NULL; runner = runner->pozi) {
//			if(*runner->word != i+52) continue; // щоб виводити лише букви з "А" (якщо додавали у словник все підряд)
			printf("%s\n", runner->word);
		}
/*
		for( ; runner != NULL; runner = runner->pozi) {// щоб виводити лише букви з "а"
//			if(*runner->word != index+84) continue;
			printf("%s\n", runner->word);
		}

*/
	}
}
/*
void hash_print(struct eWord* arr, int size){
	for (int index = 0; index<size; index++){
		if (arr == NULL) {arr++; continue;} // to avoid void string
		printf("%c \n%s\n", index+65, arr->word);
		for(struct eWord* runner = arr++->nega; runner != NULL; runner = runner->nega)
			printf("%s\n", runner->word);

		printf("\n");
	}
}
*/