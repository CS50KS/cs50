#!/usr/bin/env php
<?php

  $status = false;
  if (!$_POST) return $status;

  // the e-mail
  $mail = "my_mail@gmail.com"; // Почту, куда высылать (наша)

  // the subject // Указываем тему сообщения
  // $subject = substr(htmlspecialchars(trim($_POST['subject'])), 0, 100);
  $subject = (!empty($_POST['subject'])) ? substr(htmlspecialchars(trim($_POST['subject'])), 0, 100) : "Test"; // Тернарный оператор (?), удаление лишнего, экранируем теги, обрезаем. Если пусто, то значение по умолчанию.

  // the user name (FROM)
  // $user_name = substr(htmlspecialchars(trim($_POST['user_name'])), 0, 100); // Применяем все тоже самое.
  $user_name = (!empty($_POST['user_name'])) ? substr(htmlspecialchars(trim($_POST['user_name'])), 0, 100) : "TestUser";

  // the user mail (FROM)
  // $user_mail = $_POST['user_mail'];
  $user_mail = (!empty($_POST['user_mail'])) ? $_POST['user_mail'] : "test_mail@gmail.com"; // Мэил фром (кому обратно отправить сообщение, пользователя).

  // the message
  $message = substr(htmlspecialchars(trim($_POST['message'])), 0, 1000); // Получаем сообщение, и если больше 1000, то обрезаем. 
  $message .= "\r\n"; // Новая строка
  $message .= $user_name; 
  $message = wordwrap($message, 70, "\r\n"); // Разбивает текст (если больше 1к символов), а длина строки 70 символов, вот и разбиваем на эти куски.
  $message = str_replace("\n.", "\n..", $message); //Удаляем точку в начале строки

  // the headers
  $headers = 'From: ' . $user_mail . "\r\n" . 'Reply-To: ' . $user_mail . "\r\n" . 'X-Mailer: PHP/' . phpversion(); // Формируем дополнительный заголовок, версия и всякая доп. инфа.

  // SEND MAIL
  $status = mail($mail, $subject, $message, $headers); // Та-дам! Фунция, которая отправляет сообщение. Емаил, на какой адрес, тема, сообщение и доп заголовок.
  // $status = ($status) ? "Ok!!! :=)" : "Error!!! :=("; // Вроде понятно
  echo($status); // Выводим ответ
  return $status;


?>s