(function() { //Находит нашу форму, валидацию, формирует и кодирует сообщение
  
  var feedback = document.querySelector("#feedback-form");
  if (!feedback) return; // Проверка 
  var overlay = document.querySelector(".overlay"); // Если кнопка закрыть и понадобится при успешности самому закрыть форму
  
  feedback.addEventListener("submit", function(event) { // Назначаем событие (отправка формы). Передали евент. 
    
    event = event || window.event; // Поддержка ИЕ8
    event.preventDefault();  // 
    
    var feedbackForm = this;  //Создаем переменную и присваиваем значение объекта, на котором произошло событие
    var formData = "user_name=" + encodeURIComponent(feedbackForm.user_name.value); // Переводим знаки в нужную кодировку (юникод) Все, что успела
    formData += "&user_mail=" + encodeURIComponent(feedbackForm.user_mail.value); // Формируем вторую пару через амперсант. Таким образом соединяем строчку.
    formData += "&subject=" + encodeURIComponent(feedbackForm.subject.value); // Передали тему
    formData += "&message=" + encodeURIComponent(feedbackForm.message.value); // И сообщение
    alert(formData); // Проверка. Строчка сформированная, которую мы передадим.
    
    var xhr = new XMLHttpRequest(); // Это и есть наш AJAX. Создаем запрос к серверу. Открыть соединение с нашим сервером. 
    xhr.open("POST", "/send_mail.php", true); // Наш обработчик, куда отправляем, включаем ассинхронность
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); // 
    xhr.send(formData); // Данные, которые мы туда передаем
    
    xhr.onreadystatechange = function() { // Действие, отслеживаем нашу передачу (состояние) и назначаем функцию.
      
      if (xhr.readyState == 4 && xhr.status == 200) { // Если все совпадает, тоооооо...
          
        feedbackForm.user_name.value = ""; // Назначаем функцию успеха. Очищаем поля
        feedbackForm.user_mail.value = "";
        feedbackForm.subject.value = "";
        feedbackForm.message.value = "";
        overlay.classList.remove("overlay--visible"); // Закрываем нашу форму. Можем добавить ЧТО угодно)
          
      };
      
    };
    
    xhr.onerror = function() { // Если получаем ошибку, то очищаем поля и не закрываем форму.
      
      feedbackForm.user_name.value = "";
      feedbackForm.user_mail.value = "";
      feedbackForm.subject.value = "";
      feedbackForm.message.value = "";
      
    };
    
  }, false);
  
})();