(function() {
  
  var slideshow = document.querySelector("#slideshow");
  if (!slideshow) return;
  
  var gallery = slideshow.querySelector(".slideshow__gallery");
  if (!gallery) return;
  
  var slides = gallery.querySelectorAll(".slideshow__slide");
  if (!slides) return;
  var gallerySize = slides.length;
  
  var visibleSlide = 0;
  slides[visibleSlide].classList.add("slideshow__slide--visible");
  
  var toggle = slideshow.querySelector(".slideshow__toggle");
  if (!toggle) return;
  
  var prevButton = toggle.querySelector(".slideshow__btn--prev");
  var nextButton = toggle.querySelector(".slideshow__btn--next");
  if (!prevButton || !nextButton) return;
  
  function nextSlide() {
    
    slides[visibleSlide].classList.remove("slideshow__slide--visible");
    visibleSlide = (visibleSlide + 1) % gallerySize;
    slides[visibleSlide].classList.add("slideshow__slide--visible");
    
  };
  
  function prevSlide() {
    
    slides[visibleSlide].classList.remove("slideshow__slide--visible");
    visibleSlide = (visibleSlide - 1);
    if (visibleSlide < 0) {
        
        visibleSlide = gallerySize - 1;
        
    };
    slides[visibleSlide].classList.add("slideshow__slide--visible");
    
  }
  
  function stopShow() {
    
    clearInterval(startShow);
    
  };
  
  var startShow = setInterval(nextSlide, 3000);
  nextButton.addEventListener("click", nextSlide, false);
  nextButton.addEventListener("click", stopShow, false);
  prevButton.addEventListener("click", prevSlide, false);
  prevButton.addEventListener("click", stopShow, false);
  
})();