#include <cs50.h>
#include <stdio.h>
// посчитать количество элементов;
// принтлист;
// добавить новый элемент (начало, конец, средину);
struct node {
    int data;
    struct node* pointer;
};

int main(void)
{
    
    struct node* head = NULL;
    
    head = malloc(sizeof(struct node)); // malloc повертає адресу пам'яті, і тепер head посилається на певну ділянку памяті
    head -> pointer = malloc(sizeof(struct node));
    struct node* crawler = head;
    crawler = crawler -> pointer; // пересуває вказівник crawler на наступний елемент
    crawler -> pointer = malloc(sizeof(struct node));
    crawler = crawler -> pointer;
    crawler -> pointer = NULL;
    crawler = head;
    crawler -> data = 1;
    crawler = crawler -> pointer;
    crawler -> data = 2;
    crawler = crawler -> pointer;
    crawler -> data = 3;
    
}