#include <cs50.h>
#include <stdio.h>
// посчитать количество элементов;
// принтлист;
// добавить новый элемент (начало, конец, средину);
struct node {
    int data;
    struct node* pointer;
}

void list_ant(struct node* start, int some_e, int new_e);
void list_add(struct node* start, int some_e, int new_e);

int main(void)
{

}


void list_ant(struct node* start, int some_e, int new_e){
    struct node *glomer = start;
//
    if ()
// search plece before element (with date some_e):
    while(glomer -> data != some_e){
        glomer = glomer -> pointer;
    }
// if we want add element AFTER element with some_e:
    while(glomer -> pointer -> data == some_e){
        glomer = glomer -> pointer;
    }

    struct node* new_element = malloc(sizeof(struct node));
    new_element -> data = new_e;
    new_element -> pointer = glomer -> pointer; // first of all - connect new_e with another
    glomer = new_element;
}

void list_add(struct node* start, int some_e, int new_e){
    struct node *glomer = start;
//
    if ()
// search plece before element (with date some_e):
    while(glomer -> data != some_e){
        glomer = glomer -> pointer;
    }
// if we want add element AFTER element with some_e:
    while(glomer -> pointer -> data == some_e){
        glomer = glomer -> pointer;
    }

    struct node* new_element = malloc(sizeof(struct node));
    new_element -> data = new_e;
    new_element -> pointer = glomer -> pointer; // first of all - connect new_e with another
    glomer = new_element;
}