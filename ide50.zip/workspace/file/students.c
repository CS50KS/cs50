#include <cs50.h>
#include <stdio.h>
// Добавить сортировку, фильтрацию

struct student{
    char firstname[20];
    char lastname[20];
    int age;
    char gender[1];
};

int main(void)
{
    
    struct student list[5];
    
    FILE* myfile = fopen("data.txt", "r");
   if (myfile == NULL)
    {
       printf("ERROR!!!\n");
       return 1;
    }   
    int i = 0;
    while (fscanf(myfile, "%s%s%d%s", list[i].firstname, list[i].lastname, &(list[i].age), list[i].gender) != EOF) {
        
        printf("%s %s %d %s\n", list[i].firstname, list[i].lastname, list[i].age, list[i].gender);
        i++;
    };
    
    
    fclose(myfile);
}