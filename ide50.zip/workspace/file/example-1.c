#include <cs50.h>
#include <stdio.h>

int main(void)
{
   char* filename;
   printf("Please enter filename: ");
   filename = GetString();
   
   FILE* myfile;
   myfile = fopen(filename, "r");
   
   if (myfile == NULL)
   {
       printf("ERROR!!!");
       return 1;
   };
   int cou  nt = 0;
   int line = 0;
   
   for(int c = fgetc(myfile); c != EOF; c = fgetc(myfile))
   {
      count++;
      if(c == '\n')
      {
          line++;
      };
   }
   
   printf("Всего символов = %d\n", count);
   printf("All lines = %d\n", line);
   fclose(myfile);
}