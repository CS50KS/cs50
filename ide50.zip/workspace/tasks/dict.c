/****************************************************************************
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 ***************************************************************************/

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>


#include "dictionary.h"

// Домашка: Хеш функция и чистильщик!!





int hash(const char* word);


struct slovo {
    char* word;
    struct slovo* pointer;
};

#define HASHTABLE 27
struct slovo* hash_table[HASHTABLE];


int count =0;
char word[LENGTH + 1];

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{
    
    struct slovo* crawler = malloc(sizeof(struct slovo));
    
     int bucket = hash(word); // Oпределение индекса согласно хеш функции.
    
   
    crawler = hash_table[bucket];
    while(crawler != NULL)
    {
        if(strcasecmp(crawler-> word, word) == 0)
        {
            return true;
        }
        crawler = crawler -> pointer;
    
    }

    return false;
}


/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    
    // 1. Открыть файл для чтения.
    FILE* fp = fopen(dictionary, "r");
    if (fp == NULL)
    {
        printf("Couldn't open");
        return false;
    };
    
    // 2. Считывание пословно (построчно) сканф.

    while (fscanf(fp, "%s\n", word) != EOF)
    {
        // initialize new node
        struct slovo *temp = malloc(sizeof(struct slovo));

        // initiate first pointer
        temp->word = malloc(strlen(word) + 1);

        // copy word into pointer
        strcpy(temp->word, word);

        // hash the word
        int hashed = hash(word);

        // if new belongs at head, prepend
        if (hash_table[hashed] == NULL)
        {
            hash_table[hashed] = temp;
            temp->pointer = NULL;
        }

        // if belongs in middle or end
        else
        {
            temp->pointer = hash_table[hashed];
            hash_table[hashed] = temp;
        }

        // count words
        count++;
    }

    // close dictionnary
    fclose(fp);

    // that's all folks!
    return true;
}


// hash function 
int hash(const char* word)
{
    // initialize index to 0
    int index = 0;

    // sum ascii values
    for (int i = 0; word[i] != '\0'; i++)
        // search for lower cases words
        index += tolower(word[i]);

    // mod by size to stay w/in bound of table
    return index % HASHTABLE;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    // TODO
    return count;
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    // TODO

    for (int i = 0; i < HASHTABLE; i++)
    {
        // initiate a cursor
      struct slovo *cursor;

        // place the cursor inside the hashtable
        cursor = hash_table[i];

        while (cursor)
        {
            struct slovo* tmp = cursor;
            cursor = cursor->pointer;
            free(tmp);
            return true;
        }

        // clean the hashtable
        hash_table[i] = NULL;
    }

    return false;
}

// Пройтись по всей хеш функции. Перебрать все хеш табле индекс. Фор по размеру списка. 
    // Определить краулер и еще одну временную переменную. 
    // Должны запомнить первый элемент, краулер перенести на другой, а этот очистить (после краулера через фри).
    // Потом почистить сам хештабле индекс после цикла. (Есть видосик)