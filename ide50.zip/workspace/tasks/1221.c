#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{//Привіт :)
    printf("Enter something: \n");
    string number = GetString(); //
    if (strlen(number) %2 == 0) // если длина введенного числа четная, то выполняем..
    {
        for (int x = 0; x < strlen(number) / 2; x++)
        { // при х = 0 (просто переменная для счетчика), х меньше половины количества символов, то виконується умова циклу, а значить - виконується тіло циклу, и пошел следующий круг)
            if (number[x] != number[strlen(number) - x - 1]) // множество или массив введеных значений (зачем здесь массив-вводят то одно число) не равен числус индексом[длина числа - 0 - 1]
            { // а вот и мистер массив символов. Мг. Массив- это количество данных одного типа. В данном случае - это вводимые пользователем числа? 
                printf("x = %i, lenth-x = %i\n", number[x], number[strlen(number) - x]); // Такий прийом допомагає орієнтуватися у тому, що робить програма
                printf("Some dafference \n");
                break;
            }
        }
    } 
    else
    { // якщо непарна, то
        for (int x = 0; x != (strlen(number) - x - 1); x++)
        {
            if (number[x] != number[strlen(number) - x - 1]) 
            {
                printf("x = %i, lenth-x = %i\n", number[x], number[strlen(number) - x]); // Такий прийом допомагає орієнтуватися у тому, що робить програма
                printf("Some nodafference \n");
                break;
            }
        }
    }
    printf("\n");
}