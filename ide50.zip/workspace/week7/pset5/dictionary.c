/****************************************************************************
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 ***************************************************************************/

#include <stdbool.h>
#include <string.h>
#include "dictionary.h"

// Домашка: Хеш функция и чистильщик!!

struct slovo {
    char word [46];
    struct slovo* pointer;
};

struct slovo* hash_table[26] = {NULL};
int count =0;

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{
    int index;
    index = getindex(word); // Oпределение индекса согласно хеш функции.
    
    if(hash_table[index] == NULL)
    {
        return false;    
    }
    struct slovo* crawler = hash_table[index];
    while(crawler != NULL)
    {
        if(strcmp(crawler-> word, word) == 0)
        {
            return true;
        }
        crawler = crawler -> pointer;
    
    }

    return false;
}


/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    
    // 1. Открыть файл для чтения.
    FILE* fp = fopen(dictionary, "r");
    if (fp == NULL)
    {
        printf("Couldn't open");
        return false;
    };
    
    // 2. Считывание пословно (построчно) сканф.
    char fword[LENGTH + 1];
    int index;
    while(fscanf(fp, "%s", fword) != EOF)
    {
        //Разложить все по хэштаблицам. Проверка элементов.
        index = getindex(fword);
        if(hash_table[index] == NULL)
        {
            hash_table[index] = malloc(sizeof(struct slovo));
            strcpy(hash_table[index] -> word, fword);
         //   hash_table[index] -> word = fword; // А сработает ли это всё?
            hash_table[index] -> pointer = NULL;
            
            
        }
        else
        {
            struct slovo* temp = malloc(sizeof(struct slovo));
            temp -> pointer = hash_table[index];
            hash_table[index] = temp;
            strcpy(hash_table[index] -> word, fword);
            
        }
       count++;
    }
    fclose(fp);
    return true;
    
    
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    // TODO
    return count;
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    // Пройтись по всей хеш функции. Перебрать все хеш табле индекс. Фор по размеру списка. 
    // Определить краулер и еще одну временную переменную. 
    // Должны запомнить первый элемент, краулер перенести на другой, а этот очистить (после краулера через фри).
    // Потом почистить сам хештабле индекс после цикла. (Есть видосик)
    return false;
}
